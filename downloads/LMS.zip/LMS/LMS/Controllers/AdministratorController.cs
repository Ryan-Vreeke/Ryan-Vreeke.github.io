﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using LMS.Models.LMSModels;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace LMS.Controllers
{
    [Authorize(Roles = "Administrator")]
    public class AdministratorController : CommonController
    {
        public IActionResult Index()
        {
            return View();
        }

        public IActionResult Department(string subject)
        {
            ViewData["subject"] = subject;
            return View();
        }

        public IActionResult Course(string subject, string num)
        {
            ViewData["subject"] = subject;
            ViewData["num"] = num;
            return View();
        }

        /*******Begin code to modify********/

        /// <summary>
        /// Returns a JSON array of all the courses in the given department.
        /// Each object in the array should have the following fields:
        /// "number" - The course number (as in 5530)
        /// "name" - The course name (as in "Database Systems")
        /// </summary>
        /// <param name="subject">The department subject abbreviation (as in "CS")</param>
        /// <returns>The JSON result</returns>
        public IActionResult GetCourses(string subject)
        {
            //select * from Courses where Abbrv == 'subject';
            var query = from d in db.Courses
                        where d.Department == subject
                        select new
                        {
                            name = d.Name,
                            number = d.Number
                        };

            return Json(query.ToArray());
        }

        /// <summary>
        /// Returns a JSON array of all the professors working in a given department.
        /// Each object in the array should have the following fields:
        /// "lname" - The professor's last name
        /// "fname" - The professor's first name
        /// "uid" - The professor's uid
        /// </summary>
        /// <param name="subject">The department subject abbreviation</param>
        /// <returns>The JSON result</returns>
        public IActionResult GetProfessors(string subject)
        {
            //select * from Courses where Abbrv == 'subject';
            var query = from p in db.Professors
                        where p.WorksIn == subject
                        select new
                        {
                            lname = p.LName,
                            fname = p.FName,
                            uid = p.UId
                        };

            return Json(query.ToArray());
        }

        /// <summary>
        /// Creates a course.
        /// A course is uniquely identified by its number + the subject to which it belongs
        /// </summary>
        /// <param name="subject">The subject abbreviation for the department in which the course will be added</param>
        /// <param name="number">The course number</param>
        /// <param name="name">The course name</param>
        /// <returns>A JSON object containing {success = true/false},
        /// false if the Course already exists.</returns>
        public IActionResult CreateCourse(string subject, int number, string name)
        {
            // check to see if the course already exists
            var check = from co in db.Courses
                        where co.Department == subject && co.Number == number && co.Name == name
                        select co;

            if (check.Any())
            {
                // already exists
                return Json(new { success = false });
            }
            else
            {
                Courses c = new Courses();
                c.Department = subject;
                c.Number = (uint)number;
                c.Name = name;
                //creating a course with name and number

                try
                {
                    db.Courses.Add(c);
                    db.SaveChanges();
                    return Json(new { success = true });
                }
                catch
                {
                    return Json(new { success = false });
                }
            }
        }

        /// <summary>
        /// Creates a class offering of a given course.
        /// </summary>
        /// <param name="subject">The department subject abbreviation</param>
        /// <param name="number">The course number</param>
        /// <param name="season">The season part of the semester</param>
        /// <param name="year">The year part of the semester</param>
        /// <param name="start">The start time</param>
        /// <param name="end">The end time</param>
        /// <param name="location">The location</param>
        /// <param name="instructor">The uid of the professor</param>
        /// <returns>A JSON object containing {success = true/false}. 
        /// false if another class occupies the same location during any time 
        /// within the start-end range in the same semester, or if there is already
        /// a Class offering of the same Course in the same Semester.</returns>
        public IActionResult CreateClass(string subject, int number, string season, int year, DateTime start, DateTime end, string location, string instructor)
        {
            // check for an existing class that is in the same location
            // and happens around the same time or within the time range of the new one
            var checkLoc = from co in db.Courses
                           join cl in db.Classes on co.CatalogId equals cl.Listing into cocl

                           from x in cocl
                           where x.Location == location && x.StartTime <= start.TimeOfDay && x.EndTime >= end.TimeOfDay
                                    && x.Season == season && x.Year == year
                           select x;

            // check to see if the class already exists in the semester
            var checkSem = from co in db.Courses
                           join cl in db.Classes on co.CatalogId equals cl.Listing into coco

                           from x in coco
                           where co.Department == subject && co.Number == number && x.Season == season
                                    && x.Year == year
                           select x;

            if(checkLoc.Any() || checkSem.Any())
            {
                // if either query returns anything from the table, then either the class already exists
                // or another class uses that location around the same time
                return Json(new { success = false });
            }
            else
            {
                // otherwise, time to create a new class instance
                // get the catalog ID of the course where the new class belongs to
                var innerQuery = from k in db.Courses
                                 where k.Department == subject && k.Number == number
                                 select k;

                // creating the new class
                Classes c = new Classes();
                c.Season = season;
                c.Year = (uint)year;
                c.Location = location;
                c.StartTime = start.TimeOfDay;
                c.EndTime = end.TimeOfDay;
                c.Listing = innerQuery.First().CatalogId;
                c.TaughtBy = instructor;

                //try to add and update db if so return true else false
                try
                {
                    db.Classes.Add(c);
                    db.SaveChanges();
                    return Json(new { success = true });
                }
                catch
                {
                    return Json(new { success = false });
                }
            }
        }


        /*******End code to modify********/

    }
}