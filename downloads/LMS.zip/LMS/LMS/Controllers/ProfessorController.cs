﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using LMS.Models.LMSModels;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace LMS.Controllers
{
    [Authorize(Roles = "Professor")]
    public class ProfessorController : CommonController
    {
        public IActionResult Index()
        {
            return View();
        }

        public IActionResult Students(string subject, string num, string season, string year)
        {
            ViewData["subject"] = subject;
            ViewData["num"] = num;
            ViewData["season"] = season;
            ViewData["year"] = year;
            return View();
        }

        public IActionResult Class(string subject, string num, string season, string year)
        {
            ViewData["subject"] = subject;
            ViewData["num"] = num;
            ViewData["season"] = season;
            ViewData["year"] = year;
            return View();
        }

        public IActionResult Categories(string subject, string num, string season, string year)
        {
            ViewData["subject"] = subject;
            ViewData["num"] = num;
            ViewData["season"] = season;
            ViewData["year"] = year;
            return View();
        }

        public IActionResult CatAssignments(string subject, string num, string season, string year, string cat)
        {
            ViewData["subject"] = subject;
            ViewData["num"] = num;
            ViewData["season"] = season;
            ViewData["year"] = year;
            ViewData["cat"] = cat;
            return View();
        }

        public IActionResult Assignment(string subject, string num, string season, string year, string cat, string aname)
        {
            ViewData["subject"] = subject;
            ViewData["num"] = num;
            ViewData["season"] = season;
            ViewData["year"] = year;
            ViewData["cat"] = cat;
            ViewData["aname"] = aname;
            return View();
        }

        public IActionResult Submissions(string subject, string num, string season, string year, string cat, string aname)
        {
            ViewData["subject"] = subject;
            ViewData["num"] = num;
            ViewData["season"] = season;
            ViewData["year"] = year;
            ViewData["cat"] = cat;
            ViewData["aname"] = aname;
            return View();
        }

        public IActionResult Grade(string subject, string num, string season, string year, string cat, string aname, string uid)
        {
            ViewData["subject"] = subject;
            ViewData["num"] = num;
            ViewData["season"] = season;
            ViewData["year"] = year;
            ViewData["cat"] = cat;
            ViewData["aname"] = aname;
            ViewData["uid"] = uid;
            return View();
        }

        /*******Begin code to modify********/


        /// <summary>
        /// Returns a JSON array of all the students in a class.
        /// Each object in the array should have the following fields:
        /// "fname" - first name
        /// "lname" - last name
        /// "uid" - user ID
        /// "dob" - date of birth
        /// "grade" - the student's grade in this class
        /// </summary>
        /// <param name="subject">The course subject abbreviation</param>
        /// <param name="num">The course number</param>
        /// <param name="season">The season part of the semester for the class the assignment belongs to</param>
        /// <param name="year">The year part of the semester for the class the assignment belongs to</param>
        /// <returns>The JSON array</returns>
        public IActionResult GetStudentsInClass(string subject, int num, string season, int year)
        {
            //select fName, lName, uID, Dob, Grade from Courses natural join Classes natural join Enrolled
            //natural join Students where CatalogID = Listing and uID = Student; 
            var query = from e in db.Enrolled
                        join c in db.Classes on e.Class equals c.ClassId
                        join co in db.Courses on c.Listing equals co.CatalogId
                        join s in db.Students on e.Student equals s.UId into eccos

                        from x in eccos
                        where co.Department == subject && co.Number == num && c.Season == season && c.Year == year
                        select new
                        {
                            fname = x.FName,
                            lname = x.LName,
                            uid = x.UId,
                            dob = x.Dob,
                            grade = e.Grade
                        };

            return Json(query.ToArray());
        }

        /// <summary>
        /// Returns a JSON array with all the assignments in an assignment category for a class.
        /// If the "category" parameter is null, return all assignments in the class.
        /// Each object in the array should have the following fields:
        /// "aname" - The assignment name
        /// "cname" - The assignment category name.
        /// "due" - The due DateTime
        /// "submissions" - The number of submissions to the assignment
        /// </summary>
        /// <param name="subject">The course subject abbreviation</param>
        /// <param name="num">The course number</param>
        /// <param name="season">The season part of the semester for the class the assignment belongs to</param>
        /// <param name="year">The year part of the semester for the class the assignment belongs to</param>
        /// <param name="category">The name of the assignment category in the class, 
        /// or null to return assignments from all categories</param>
        /// <returns>The JSON array</returns>
        public IActionResult GetAssignmentsInCategory(string subject, int num, string season, int year, string category)
        {
            var query = from co in db.Courses
                        join c in db.Classes on co.CatalogId equals c.Listing into left

                        from x in left
                        where co.Department == subject && co.Number == num && x.Season == season && x.Year == year
                        select new
                        {
                            cID = x.ClassId
                        };
            uint cID = query.FirstOrDefault().cID;

            var acQ = from ag in db.AssignmentCategories
                      where ag.Name == category && ag.InClass == cID
                      select new
                      {
                          agID = ag.CategoryId
                      };

            if (acQ.FirstOrDefault() == null)
            {
                var aQuery = from ag in db.AssignmentCategories
                             join a in db.Assignments on ag.CategoryId equals a.Category into f

                             from x in f
                             where ag.InClass == cID
                             select new
                             {
                                 aname = x.Name,
                                 cname = ag.Name,
                                 due = x.Due,
                                 submissions = (from s in db.Submissions where x.AssignmentId == s.Assignment select s.Assignment).Count()
                             };
                return Json(aQuery.ToArray());
            }
            else
            {
                var asq = from ag in db.AssignmentCategories
                          join a in db.Assignments on ag.CategoryId equals a.Category into f

                          from x in f
                          where ag.InClass == cID && ag.Name == category
                          select new
                          {
                              aname = x.Name,
                              cname = ag.Name,
                              due = x.Due,
                              submissions = (from s in db.Submissions where x.AssignmentId == s.Assignment select s.Assignment).Count()
                          };
                return Json(asq.ToArray());
            }
        }


        /// <summary>
        /// Returns a JSON array of the assignment categories for a certain class.
        /// Each object in the array should have the folling fields:
        /// "name" - The category name
        /// "weight" - The category weight
        /// </summary>
        /// <param name="subject">The course subject abbreviation</param>
        /// <param name="num">The course number</param>
        /// <param name="season">The season part of the semester for the class the assignment belongs to</param>
        /// <param name="year">The year part of the semester for the class the assignment belongs to</param>
        /// <param name="category">The name of the assignment category in the class</param>
        /// <returns>The JSON array</returns>
        public IActionResult GetAssignmentCategories(string subject, int num, string season, int year)
        {
            var query = from co in db.Courses
                        join c in db.Classes on co.CatalogId equals c.Listing
                        join ag in db.AssignmentCategories on c.ClassId equals ag.InClass into fin


                        from x in fin
                        where co.Department == subject && co.Number == num && c.Season == season && c.Year == year
                        select new
                        {
                            name = x.Name,
                            weight = x.Weight
                        };

            return Json(query.ToArray());
        }

        /// <summary>
        /// Creates a new assignment category for the specified class.
        /// </summary>
        /// <param name="subject">The course subject abbreviation</param>
        /// <param name="num">The course number</param>
        /// <param name="season">The season part of the semester for the class the assignment belongs to</param>
        /// <param name="year">The year part of the semester for the class the assignment belongs to</param>
        /// <param name="category">The new category name</param>
        /// <param name="catweight">The new category weight</param>
        /// <returns>A JSON object containing {success = true/false},
        ///	false if an assignment category with the same name already exists in the same class.</returns>
        public IActionResult CreateAssignmentCategory(string subject, int num, string season, int year, string category, int catweight)
        {
            // check to see if the assignment category exists already
            var check = from co in db.Courses
                        join cl in db.Classes on co.CatalogId equals cl.Listing
                        join ag in db.AssignmentCategories on cl.ClassId equals ag.InClass
                        into combo

                        from x in combo
                        where co.Department == subject && co.Number == num && cl.Season == season
                                && cl.Year == year && x.Name == category
                        select x;

            if (check.Any())
            {
                // if check contains anything, then the assignment category already exists
                // success = false
                return Json(new { success = false });
            }
            else
            {
                // otherwise, it doesn't exist, so create a new one
                // columns: categoryid (auto), name, weight, classid

                // first get the classID the category is being assigned to
                var cid = from co in db.Courses
                          join cl in db.Classes on co.CatalogId equals cl.Listing
                          where co.Department == subject && co.Number == num && cl.Season == season
                                && cl.Year == year
                          select new
                          {
                              cID = cl.ClassId
                          };

                // create the new category
                AssignmentCategories ac = new AssignmentCategories();
                ac.InClass = cid.First().cID;
                ac.Name = category;
                ac.Weight = (uint)catweight;

                // add to the database
                try
                {
                    db.AssignmentCategories.Add(ac);
                    db.SaveChanges();

                    return Json(new { success = true });
                }
                catch
                {
                    // if it doesn't work, obviously, it failed
                    return Json(new { success = false });
                }
            }
        }

        /// <summary>
        /// Creates a new assignment for the given class and category.
        /// </summary>
        /// <param name="subject">The course subject abbreviation</param>
        /// <param name="num">The course number</param>
        /// <param name="season">The season part of the semester for the class the assignment belongs to</param>
        /// <param name="year">The year part of the semester for the class the assignment belongs to</param>
        /// <param name="category">The name of the assignment category in the class</param>
        /// <param name="asgname">The new assignment name</param>
        /// <param name="asgpoints">The max point value for the new assignment</param>
        /// <param name="asgdue">The due DateTime for the new assignment</param>
        /// <param name="asgcontents">The contents of the new assignment</param>
        /// <returns>A JSON object containing success = true/false,
        /// false if an assignment with the same name already exists in the same assignment category.</returns>
        public IActionResult CreateAssignment(string subject, int num, string season, int year, string category, string asgname, int asgpoints, DateTime asgdue, string asgcontents)
        {
            // check to see if the assignment already exists in the category
            var check = from co in db.Courses
                        join cl in db.Classes on co.CatalogId equals cl.Listing
                        join ag in db.AssignmentCategories on cl.ClassId equals ag.InClass
                        join an in db.Assignments on ag.CategoryId equals an.Category
                        into combo

                        from x in combo
                        where co.Department == subject && co.Number == num && cl.Season == season
                                && cl.Year == year && ag.Name == category && x.Name == asgname
                        select x;

            if (check.Any())
            {
                // assignment already exists
                return Json(new { success = false });
            }
            else
            {
                // get the CategoryID
                var catID = from co in db.Courses
                            join cl in db.Classes on co.CatalogId equals cl.Listing
                            join ag in db.AssignmentCategories on cl.ClassId equals ag.InClass
                            into combo

                            from x in combo
                            where co.Department == subject && co.Number == num && cl.Season == season
                                    && cl.Year == year && x.Name == category
                            select x;

                // create a new assignment
                Assignments asg = new Assignments();
                asg.Category = catID.First().CategoryId;
                asg.Name = asgname;
                asg.Contents = asgcontents;
                asg.Due = asgdue;
                asg.MaxPoints = (uint)asgpoints;

                // add to database
                try
                {
                    db.Assignments.Add(asg);
                    db.SaveChanges();
                }
                catch
                {
                    return Json(new { success = false });
                }

                var classAndStudents = from e in db.Enrolled
                                       join c in db.Classes on e.Class equals c.ClassId
                                       join co in db.Courses on c.Listing equals co.CatalogId into joined

                                       from j in joined
                                       where j.Department == subject && j.Number == num && c.Season == season && c.Year == year
                                       select new
                                       {
                                           cID = c.ClassId,
                                           student = e.Student,

                                       };

                // update the student's grade
                foreach(var sc in classAndStudents)
                {
                    if (!UpdateGrade(sc.cID, sc.student))
                    {
                        return Json(new { success = false });
                    }
                }

                return Json(new { success = true });
            }
        }


        /// <summary>
        /// Gets a JSON array of all the submissions to a certain assignment.
        /// Each object in the array should have the following fields:
        /// "fname" - first name
        /// "lname" - last name
        /// "uid" - user ID
        /// "time" - DateTime of the submission
        /// "score" - The score given to the submission
        /// 
        /// </summary>
        /// <param name="subject">The course subject abbreviation</param>
        /// <param name="num">The course number</param>
        /// <param name="season">The season part of the semester for the class the assignment belongs to</param>
        /// <param name="year">The year part of the semester for the class the assignment belongs to</param>
        /// <param name="category">The name of the assignment category in the class</param>
        /// <param name="asgname">The name of the assignment</param>
        /// <returns>The JSON array</returns>
        public IActionResult GetSubmissionsToAssignment(string subject, int num, string season, int year, string category, string asgname)
        {
            // find the assignment in question
            var query1 = from co in db.Courses
                         join c in db.Classes on co.CatalogId equals c.Listing
                         join ag in db.AssignmentCategories on c.ClassId equals ag.InClass
                         join a in db.Assignments on ag.CategoryId equals a.Category into left

                         from x in left
                         where co.Department == subject && co.Number == num && c.Season == season && c.Year == year && ag.Name == category && x.Name == asgname
                         select new
                         {
                             assignment = x.AssignmentId
                         };

            // then find all the submissions and the students associated with them
            var query2 = from q in query1
                         join s in db.Submissions on q.assignment equals s.Assignment
                         join st in db.Students on s.Student equals st.UId into left
                         from x in left
                         select new
                         {
                             fname = x.FName,
                             lname = x.LName,
                             uid = x.UId,
                             time = s.Time,
                             score = s.Score
                         };

            return Json(query2.ToArray());
        }


        /// <summary>
        /// Set the score of an assignment submission
        /// </summary>
        /// <param name="subject">The course subject abbreviation</param>
        /// <param name="num">The course number</param>
        /// <param name="season">The season part of the semester for the class the assignment belongs to</param>
        /// <param name="year">The year part of the semester for the class the assignment belongs to</param>
        /// <param name="category">The name of the assignment category in the class</param>
        /// <param name="asgname">The name of the assignment</param>
        /// <param name="uid">The uid of the student who's submission is being graded</param>
        /// <param name="score">The new score for the submission</param>
        /// <returns>A JSON object containing success = true/false</returns>
        public IActionResult GradeSubmission(string subject, int num, string season, int year, string category, string asgname, string uid, int score)
        {
            // find the assignment
            var assign = from co in db.Courses
                         join cl in db.Classes on co.CatalogId equals cl.Listing
                         join ac in db.AssignmentCategories on cl.ClassId equals ac.InClass
                         join an in db.Assignments on ac.CategoryId equals an.Category
                         into asn

                         from x in asn
                         where co.Department == subject && co.Number == num && cl.Season == season
                                && cl.Year == year && ac.Name == category && x.Name == asgname
                         select x;

            // check to see if there is a submission from that student
            var submit = from a in assign
                         join sb in db.Submissions on a.AssignmentId equals sb.Assignment
                         where sb.Student == uid
                         select sb;

            if (submit.Any())
            {
                // if the query returned anything, the student has submitted an assignment
                submit.First().Score = (uint)score;
                try
                {
                    db.SaveChanges();
                }
                catch
                {
                    // something happened while trying to save the changes, so abort?
                    return Json(new { success = false });
                }
            }
            else
            {
                // the query didn't return anything--the student hasn't submitted the assignment
                // create a new "dummy" submission to assign a zero (that's rough, buddy)
                Submissions sub = new Submissions();
                sub.Assignment = assign.First().AssignmentId;
                sub.Score = 0;
                sub.Student = uid;
                sub.SubmissionContents = null;
                sub.Time = DateTime.Now;
                try
                {
                    db.SaveChanges();
                }
                catch
                {
                    // something happened while trying to save the changes, so abort?
                    return Json(new { success = false });
                }
            }

            var classQuery = from c in db.Classes
                                   join co in db.Courses on c.Listing equals co.CatalogId into joined

                                   from j in joined
                                   where j.Department == subject && j.Number == num && c.Season == season && c.Year == year
                                   select new
                                   {
                                       cID = c.ClassId
                                   };

            // update the student's grade
            if (UpdateGrade(classQuery.FirstOrDefault().cID, uid))
                return Json(new { success = true });
            else
                return Json(new { success = false });

        }


        private bool UpdateGrade(uint classID, string uid)
        {
            // the sum of the weights of Asssignment Categories in the class
            double catWeightSum = 0;
            // the sum of a student's grade across all categories in the class
            double allCatPercent = 0;
            // the final grade
            double finalScore = 0;

            // list of categories for the class in question
            var cats = from ag in db.AssignmentCategories
                       where ag.InClass == classID
                       select new
                       {
                           catID = ag.CategoryId,
                           weight = ag.Weight,
                       };

            // iterate through category
            foreach (var c in cats)
            {
                // find all the assignments to c
                var asn = from a in db.Assignments
                          where a.Category == c.catID
                          select new
                          {
                              maxpoints = a.MaxPoints,
                              aID = a.AssignmentId
                          };

                // declare variables to calculate total max points and total earned points
                // of a submission and assignment
                uint totalMax = 0;
                uint totalScore = 0;

                // iterate through each individual assignment
                foreach (var a in asn)
                {
                    // total the max points
                    // since we're still in the foreach of the category, it will be within the category
                    totalMax += a.maxpoints;

                    // now find the submission from the specific student
                    var sub = from s in db.Submissions
                              where s.Assignment == a.aID && s.Student == uid
                              select new
                              {
                                  score = s.Score
                              };

                    // if the query returns anything, then there is a submission
                    // add the earned score to the total score
                    if (sub.Any())
                        totalScore += sub.FirstOrDefault().score;

                    // if there is no submission, it's a zero
                    // adding it to the score doesn't change it, so there's no reason to do anything
                }

                // all of the assignments of current category has been iterated through
                // both the total max points and total score have been calculated
                // find the percentage of the category
                if (asn.Any())
                {

                    double catPercent = ((double)totalScore / (double)totalMax) * c.weight;

                    // add that to the overall total to be used later
                    allCatPercent += catPercent;

                    catWeightSum += c.weight;
                }
            }
            // all of the categories of this class have been iterated through
            // the student's grade across all categories have been calculated
            // the total max weight of the class has been calculated
            // find the scale factor to make it to make it out of 100%
            double scaleFactor = 100 / catWeightSum;

            // use the scale factor to calculate the final score
            finalScore = scaleFactor * allCatPercent;

            // update it in the database
            var setGrade = from e in db.Enrolled
                           where e.Class == classID && e.Student == uid
                           select e;

            // calculate the letter grade at the same time as saving it
            setGrade.FirstOrDefault().Grade = CalculateLetterGrade(finalScore);

            // save the changes
            try
            {
                db.SaveChanges();
                return true;
            }
            catch
            {
                return false;
            }
        }


        /// <summary>
        /// Helper method
        /// </summary>
        /// <param name="percentage">The final grade based on all assignments and submissions.</param>
        /// <returns>A string containing the letter grade based on the percentage.</returns>
        private string CalculateLetterGrade(double percentage)
        {

            if (percentage > 93)
                return "A";
            else if ((percentage <= 93.0) && (percentage > 90.0))
                return "A-";
            else if ((percentage <= 90.0) && (percentage > 87.0))
                return "B+";
            else if ((percentage <= 87.0) && (percentage > 83.0))
                return "B";
            else if ((percentage <= 83.0) && (percentage > 80.0))
                return "B-";
            else if ((percentage <= 80.0) && (percentage > 77.0))
                return "C+";
            else if ((percentage <= 77.0) && (percentage > 73.0))
                return "C";
            else if ((percentage <= 73.0) && (percentage > 70.0))
                return "C-";
            else if ((percentage <= 70.0) && (percentage > 67.0))
                return "D+";
            else if ((percentage <= 67.0) && (percentage > 63.0))
                return "D";
            else if ((percentage <= 63.0) && (percentage > 60.0))
                return "D-";
            else
                return "E";
        }

        /// <summary>
        /// Returns a JSON array of the classes taught by the specified professor
        /// Each object in the array should have the following fields:
        /// "subject" - The subject abbreviation of the class (such as "CS")
        /// "number" - The course number (such as 5530)
        /// "name" - The course name
        /// "season" - The season part of the semester in which the class is taught
        /// "year" - The year part of the semester in which the class is taught
        /// </summary>
        /// <param name="uid">The professor's uid</param>
        /// <returns>The JSON array</returns>
        public IActionResult GetMyClasses(string uid)
        {
            var query = from co in db.Courses
                        join c in db.Classes on co.CatalogId equals c.Listing into left

                        from x in left
                        where x.TaughtBy == uid
                        select new
                        {
                            subject = co.Department,
                            number = co.Number,
                            name = co.Name,
                            season = x.Season,
                            year = x.Year,
                        };

            return Json(query.ToArray());
        }


        /*******End code to modify********/

    }
}